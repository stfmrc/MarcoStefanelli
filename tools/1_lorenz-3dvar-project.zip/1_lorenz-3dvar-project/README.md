# Lorenz 3D Variational Project

This project visualizes the Lorenz 63 model using Three.js, providing an interactive 3D representation of the model's behavior based on user-defined parameters and initial conditions.

## Project Structure

- `index.html`: The main HTML file that sets up the structure of the web page and links to the CSS and JavaScript files.
- `styles/styles.css`: Contains all the CSS styles for the project, defining the layout, colors, fonts, and other visual aspects.
- `scripts/main.js`: The JavaScript file that includes the logic for the Lorenz 63 model simulation, user input handling, and 3D visualization rendering.

## Setup Instructions

1. **Clone the Repository**: 
   Clone this repository to your local machine using:
   ```
   git clone <repository-url>
   ```

2. **Open the Project**: 
   Navigate to the project directory:
   ```
   cd lorenz-3dvar-project
   ```

3. **Open `index.html`**: 
   Open the `index.html` file in your web browser to view the Lorenz 63 model visualization.

## Usage

- Adjust the parameters (Sigma, Rho, Beta) and initial conditions (X0, Y0, Z0) using the input fields provided in the interface.
- Click the "Start" button to initiate the simulation and visualize the trajectories of the Lorenz 63 model in 3D space.

## Dependencies

This project requires the following libraries:
- [Three.js](https://threejs.org/)
- [MathJax](https://www.mathjax.org/)

Ensure you have an internet connection to load these libraries from the CDN links included in the `index.html` file.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.