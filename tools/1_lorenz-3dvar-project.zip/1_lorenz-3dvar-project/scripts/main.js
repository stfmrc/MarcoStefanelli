document.getElementById("num_timesteps").addEventListener("change", function() {
    let v = parseInt(this.value);
    if (v < 500) this.value = 500;
    if (v > 25000) this.value = 25000;
  });

  document.getElementById("obs_step").addEventListener("change", function() {
    let v = parseInt(this.value);
    if (v < 1) this.value = 1;
    if (v > 25000) this.value = 25000;
  });

let scene, camera, renderer, points1, points2, material1, material2, controls;
let trajectory1 = [], trajectory2 = [], index = 0;
let isDragging = false;
let lastMouseX = 0, lastMouseY = 0;

let bullet1, bullet2;
let isPaused = false;

function lorenz(x, y, z, sigma, rho, beta, dt) {
    let dx = sigma * (y - x) * dt;
    let dy = (x * (rho - z) - y) * dt;
    let dz = (x * y - beta * z) * dt;
    return [x + dx, y + dy, z + dz];
}

let animationFrameId = null; // Store the animation frame ID

function startSimulation() {
    if (animationFrameId) {
        cancelAnimationFrame(animationFrameId); // Stop any previous animation loop
    }


    
    let sigma = parseFloat(document.getElementById("sigma").value);
    let rho = parseFloat(document.getElementById("rho").value);
    let beta = parseFloat(document.getElementById("beta").value);
    let x1 = parseFloat(document.getElementById("x0_1").value);
    let y1 = parseFloat(document.getElementById("y0_1").value);
    let z1 = parseFloat(document.getElementById("z0_1").value);
    let x2 = parseFloat(document.getElementById("x0_2").value);
    let y2 = parseFloat(document.getElementById("y0_2").value);
    let z2 = parseFloat(document.getElementById("z0_2").value);
    let dt = 0.007;

    trajectory1 = [];
    trajectory2 = [];
    
    for (let i = 0; i < 25000; i++) {
        [x1, y1, z1] = lorenz(x1, y1, z1, sigma, rho, beta, dt);
        [x2, y2, z2] = lorenz(x2, y2, z2, sigma, rho, beta, dt);
        trajectory1.push(new THREE.Vector3(x1 * 0.2, y1 * 0.2, z1 * 0.2));
        trajectory2.push(new THREE.Vector3(x2 * 0.2, y2 * 0.2, z2 * 0.2));
    }
    
    index = 0;
    init();
    
}

function init() {
    document.getElementById("container").innerHTML = "";
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 0, 50);
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth * 0.75, window.innerHeight * 0.75);
    
    // Append renderer to container
    const container = document.getElementById("container");
    container.appendChild(renderer.domElement);

    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.rotateSpeed = 0.5;
    controls.enablePan = false;  // Disable OrbitControls pan

    // Materials
    material1 = new THREE.LineBasicMaterial({ color: 0xff0000 }); // Red for trajectory1
    material2 = new THREE.LineBasicMaterial({ color: 0x0000ff }); // Blue for trajectory2
    points1 = new THREE.Line(new THREE.BufferGeometry(), material1);
    points2 = new THREE.Line(new THREE.BufferGeometry(), material2);
    scene.add(points1);
    scene.add(points2);

    // Create the bullets (small spheres at the head of the trajectories)
    let bulletGeometry = new THREE.SphereGeometry(0.3, 8, 8);

    bullet1 = new THREE.Mesh(bulletGeometry, material1);
    bullet2 = new THREE.Mesh(bulletGeometry, material2);

    scene.add(bullet1);
    scene.add(bullet2);
    
    animate();
}


function onMouseDown(event) {
    isDragging = true;
    lastMouseX = event.clientX;
    lastMouseY = event.clientY;
}

function onMouseMove(event) {
    if (isDragging) {
        let deltaX = event.clientX - lastMouseX;
        let deltaY = event.clientY - lastMouseY;

        // Update mouse positions for next movement
        lastMouseX = event.clientX;
        lastMouseY = event.clientY;
    }
}

function onMouseUp() {
    isDragging = false;
}

function animate() {
    if (!isPaused && index < trajectory1.length) {
        points1.geometry.setFromPoints(trajectory1.slice(0, index));
        points2.geometry.setFromPoints(trajectory2.slice(0, index));
        
        bullet1.position.copy(trajectory1[index]);
        bullet2.position.copy(trajectory2[index]);
        
        
        index++;
    }
    
    controls.update();
    animationFrameId = requestAnimationFrame(animate);
    renderer.render(scene, camera);
}

function pauseResumeAnimation() {
    isPaused = !isPaused;
    document.getElementById("pauseResumeButton").textContent = isPaused ? "Resume" : "Pause";
}


function SimplifiedKF() {
    let sigma = parseFloat(document.getElementById("sigma").value);
    let rho = parseFloat(document.getElementById("rho").value);
    let beta = parseFloat(document.getElementById("beta").value);
    let x1 = parseFloat(document.getElementById("x0_1").value);
    let y1 = parseFloat(document.getElementById("y0_1").value);
    let z1 = parseFloat(document.getElementById("z0_1").value);
    let x2 = parseFloat(document.getElementById("x0_2").value);
    let y2 = parseFloat(document.getElementById("y0_2").value);
    let z2 = parseFloat(document.getElementById("z0_2").value);
    let obsStep = parseInt(document.getElementById("obs_step").value);
    let sigma_obs = parseFloat(document.getElementById("obs_sigma").value);
    let sigma_model = parseFloat(document.getElementById("model_sigma").value);
    let numTimesteps = parseInt(document.getElementById("num_timesteps").value);


    let dt = 0.007;
    
    let k = (sigma_model*sigma_model) / ((sigma_model*sigma_model) + (sigma_obs*sigma_obs));
    console.log(`Kalman gain k: ${k}`);

    let truth = [];
    let observations = [];
    let background = [];
    let analysis = [];

    let t_obs = [];
    let states_obs = [];

    let x = x1, y = y1, z = z1;

    for (let i = 0; i < 25000; i++) {
        [x, y, z] = lorenz(x, y, z, sigma, rho, beta, dt);
        truth.push([x, y, z]);

        if (i % obsStep === 0 ) {
            //let noiseX = (Math.random() - 0.5) * sigma_obs;
            //let noiseY = (Math.random() - 0.5) * sigma_obs;
            //let noiseZ = (Math.random() - 0.5) * sigma_obs;
            let noiseX = sigma_obs === 0 ? 0 : (Math.random() - 0.5) * sigma_obs;
            let noiseY = sigma_obs === 0 ? 0 : (Math.random() - 0.5) * sigma_obs;
            let noiseZ = sigma_obs === 0 ? 0 : (Math.random() - 0.5) * sigma_obs;
            let obsX = x + noiseX;
            let obsY = y + noiseY;
            let obsZ = z + noiseZ;
            observations.push([obsX, obsY, obsZ]);
            t_obs.push(i);
            states_obs.push([obsX, obsY, obsZ]);
            console.log(`i: ${i}, ${i % obsStep}`);
            console.log(`sigma_obs: ${sigma_obs}`);
            console.log(`Noise: X=${noiseX}, Y=${noiseY}, Z=${noiseZ}`);
            console.log(`True state: X=${x}, Y=${y}, Z=${z}`);
            console.log(`Observed state: X=${obsX}, Y=${obsY}, Z=${obsZ}`);
        }
    }


    let states_model = [];
    let model_x = x2, model_y = y2, model_z = z2;

    for (let i = 0; i < 25000; i++) {
        [model_x, model_y, model_z] = lorenz(model_x, model_y, model_z, sigma, rho, beta, dt);
        states_model.push([model_x, model_y, model_z]);
    }

    let assimilated_state = [];
    let [new_x, new_y, new_z] = [x2, y2, z2];

    for (let i = 1; i < states_model.length; i++) {
        if (i % obsStep === 0 && i / obsStep < states_obs.length) {
            let obs = states_obs[i / obsStep];
            if (sigma_obs === 0 && sigma_model === 0) {
                // Perfect model and perfect observations means no updates needed
                new_x = new_x;  // No change to model state
                new_y = new_y;  // No change to model state
                new_z = new_z;  // No change to model state
            } else if (sigma_obs === 0) {
                // If observations are perfect, set the model to the observed state
                new_x = obs[0];
                new_y = obs[1];
                new_z = obs[2];
            } else if (sigma_model === 0) {
                // If the model is perfect, don't update it, just evolve it naturally
                new_x = new_x;  // No update to the model
                new_y = new_y;  // No update to the model
                new_z = new_z;  // No update to the model
            } else {
                // Apply normal Kalman update
                new_x += k * (obs[0] - new_x);
                new_y += k * (obs[1] - new_y);
                new_z += k * (obs[2] - new_z);
            }
        }
        [new_x, new_y, new_z] = lorenz(new_x, new_y, new_z, sigma, rho, beta, dt);
        assimilated_state.push([new_x, new_y, new_z]);
    }

    let vectorx = [], vectory = [], vectorz = [];
    let assimilationTime = 50;

    for (let i = 0; i < assimilated_state.length; i += obsStep) {
        let forecast_x = assimilated_state[i][0];
        let forecast_y = assimilated_state[i][1];
        let forecast_z = assimilated_state[i][2];

        for (let j = 0; j < assimilationTime; j++) {
            [forecast_x, forecast_y, forecast_z] = lorenz(forecast_x, forecast_y, forecast_z, sigma, rho, beta, dt);
            vectorx.push(forecast_x);
            vectory.push(forecast_y);
            vectorz.push(forecast_z);
        }
    }

    plotResults(truth, states_model, assimilated_state, observations, obsStep, numTimesteps);
}



let chartX, chartY, chartZ;

function plotResults(truth, background, analysis, observations, obsStep, numTimesteps) {
    const ctxX = document.getElementById('chartX').getContext('2d');
    const ctxY = document.getElementById('chartY').getContext('2d');
    const ctxZ = document.getElementById('chartZ').getContext('2d');

    const labels = Array.from({ length: numTimesteps }, (_, i) => i);

    // Prepare the data for the observations (set null for non-observation times)
    let obsData1 = new Array(truth.length).fill(null); // Initialize with nulls
    let obsData2 = new Array(truth.length).fill(null); // Initialize with nulls
    let obsData3 = new Array(truth.length).fill(null); // Initialize with nulls

    for (let i = 1; i < observations.length; i++) {
        const observationIndex = i * obsStep; // Calculate the correct index based on the obsStep
        obsData1[observationIndex] = observations[i][0]; // Use the first component of the observation
        obsData2[observationIndex] = observations[i][1]; // Use the second component of the observation
        obsData3[observationIndex] = observations[i][2]; // Use the third component of the observation
        console.log(`Fill obs vect: obs index=${observationIndex}, X=${obsData1[observationIndex]}`);
    }

    // Destroy existing charts if they exist
    if (chartX) chartX.destroy();
    if (chartY) chartY.destroy();
    if (chartZ) chartZ.destroy();

    // Create the chart for X component
    chartX = new Chart(ctxX, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Observations',
                    data: obsData1, // Plots observations at the correct time steps
                    borderColor: 'white',
                    backgroundColor: 'white',
                    pointStyle: 'star',
                    pointRadius: 5, // Reduced marker size
                    fill: false,
                    showLine: false // We don't want to connect observation points
                },
                {
                    label: 'Truth',
                    data: truth.map(t => t[0]), // Assuming the X component of the truth data
                    borderColor: 'red',
                    backgroundColor: 'red',
                    borderWidth: 2,
                    pointStyle: false,
                    fill: false
                },
                {
                    label: 'Background',
                    data: background.map(b => b[0]),
                    borderColor: 'blue',
                    backgroundColor: 'blue',
                    borderWidth: 2,
                    pointStyle: false,
                    fill: false
                },
                {
                    label: 'Simplified KF',
                    data: analysis.map(a => a[0]),
                    borderColor: 'green',
                    backgroundColor: 'green',
                    borderWidth: 2,
                    pointStyle: false,
                    fill: false
                }

            ]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'X Component'
            },
            scales: {
                y: {
                    title: {
                        display: true,
                        text: 'X'
                    }
                }
            },
            plugins: {
                zoom: {
                    pan: {
                        enabled: false,
                        mode: 'y',  // Allow both horizontal and vertical movement
                        modifierKey: null, // Allows panning without pressing a key (default requires Shift)
                        overScaleMode: "y", // Ensures panning even when zoomed in
                    },
                    zoom: {
                        wheel: {
                            enabled: false
                        },
                        pinch: {
                            enabled: false
                        },
                        mode: 'xy'
                    }
                }
            }
        }
    });

    // Create the chart for Y component
    chartY = new Chart(ctxY, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Observations',
                    data: obsData2, // Plots observations at the correct time steps
                    borderColor: 'white',
                    backgroundColor: 'white',
                    pointStyle: 'star',
                    pointRadius: 5, // Reduced marker size
                    fill: false,
                    showLine: false // We don't want to connect observation points
                },
                {
                    label: 'Truth',
                    data: truth.map(t => t[1]),
                    borderColor: 'red',
                    backgroundColor: 'red',
                    borderWidth: 2,
                    pointStyle: false,
                    fill: false
                },
                {
                    label: 'Background',
                    data: background.map(b => b[1]),
                    borderColor: 'blue',
                    backgroundColor: 'blue',
                    borderWidth: 2,
                    pointStyle: false,
                    fill: false
                },
                {
                    label: 'Simplified KF',
                    data: analysis.map(a => a[1]),
                    borderColor: 'green',
                    backgroundColor: 'green',
                    borderWidth: 2,
                    pointStyle: false,
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Y Component'
            },
            scales: {
                y: {
                    title: {
                        display: true,
                        text: 'Y'
                    }
                }
            },
            plugins: {
                zoom: {
                    pan: {
                        enabled: false,
                        mode: 'xy',  // Allow both horizontal and vertical movement
                        modifierKey: null, // Allows panning without pressing a key (default requires Shift)
                        overScaleMode: "xy", // Ensures panning even when zoomed in
                    },
                    zoom: {
                        wheel: {
                            enabled: false
                        },
                        pinch: {
                            enabled: false
                        },
                        mode: 'xy'
                    }
                }
            }
        }
    });

    // Create the chart for Z component
    chartZ = new Chart(ctxZ, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Observations',
                    data: obsData3, // Plots observations at the correct time steps
                    borderColor: 'white',
                    backgroundColor: 'white',
                    pointStyle: 'star',
                    pointRadius: 5, // Reduced marker size
                    fill: false,
                    showLine: false // We don't want to connect observation points
                },
                {
                    label: 'Truth',
                    data: truth.map(t => t[2]),
                    borderColor: 'red',
                    backgroundColor: 'red',
                    borderWidth: 2,
                    pointStyle: false,
                    fill: false
                },
                {
                    label: 'Background',
                    data: background.map(b => b[2]),
                    borderColor: 'blue',
                    backgroundColor:'blue',
                    borderWidth: 2,
                    pointStyle: false,
                    fill: false
                },
                {
                    label: 'Simplified KF',
                    data: analysis.map(a => a[2]),
                    borderColor: 'green',
                    backgroundColor: 'green',
                    borderWidth: 2,
                    pointStyle: false,
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Z Component'
            },
            scales: {
                y: {
                    title: {
                        display: true,
                        text: 'Z'
                    }
                }
            },
            plugins: {
                zoom: {
                    pan: {
                        enabled: false,
                        mode: 'xy',  // Allow both horizontal and vertical movement
                        modifierKey: null, // Allows panning without pressing a key (default requires Shift)
                        overScaleMode: "xy", // Ensures panning even when zoomed in
                    },
                    zoom: {
                        wheel: {
                            enabled: false
                        },
                        pinch: {
                            enabled: false
                        },
                        mode: 'xy'
                    }
                }
            }
        }
    });
}